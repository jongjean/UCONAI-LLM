# 메뉴 드롭다운 문제 해결 보고서
**작성일**: 2024-12-30  
**상태**: ✅ 완료

---

## 📋 문제 요약

사용자가 메인메뉴 드롭다운에 메뉴가 제대로 추가되지 않는 문제를 보고했습니다.

---

## 🔍 발견된 문제들

### 1. **main.js NAVIGATION_ITEMS 배열 누락**
- **문제**: "학회소개" 섹션에 "웹 둘러보기" 메뉴가 없었음
- **위치**: `js/main.js` 18-32번 줄
- **영향**: 동적으로 생성되는 메뉴에 해당 항목이 표시되지 않음

### 2. **드롭다운 아이콘 렌더링 미지원**
- **문제**: `buildNavigationMenu()` 함수가 드롭다운 항목의 아이콘을 렌더링하지 않음
- **위치**: `js/main.js` 337-350번 줄
- **영향**: 드롭다운에 아이콘이 있는 메뉴가 텍스트만 표시됨

### 3. **includes/header.html 누락**
- **문제**: 정적 헤더 템플릿에도 "웹 둘러보기" 메뉴가 없었음
- **위치**: `includes/header.html` 17-27번 줄
- **영향**: 헤더를 include로 사용하는 페이지에서 메뉴 누락

### 4. **index.html과 main.js 불일치**
- **문제**: index.html의 정적 메뉴 구조가 main.js와 일치하지 않음
- **세부사항**:
  - "커뮤니티 > 자유게시판": `forum.html` vs `free-board.html` 혼용
  - "마이페이지" 드롭다운: `auth-only` 클래스 누락
- **영향**: 페이지별로 메뉴 동작이 다르고 로그인 상태 메뉴가 제대로 작동하지 않음

### 5. **파일 링크 중복**
- **문제**: `forum.html`과 `free-board.html` 두 파일이 존재하며 혼용됨
- **위치**: `pages/community/` 폴더
- **영향**: 메뉴 링크 불일치로 사용자 혼란

---

## ✅ 해결 방법

### 1. main.js NAVIGATION_ITEMS 업데이트
```javascript
{
    label: '학회소개',
    icon: 'fas fa-building',
    href: 'pages/about/greeting.html',
    matches: ['/pages/about/'],
    children: [
        { label: '웹 둘러보기', href: 'pages/sitemap.html', icon: 'fas fa-sitemap' }, // ✅ 추가
        { label: '학회장 인사말', href: 'pages/about/greeting-new.html' },
        // ... 나머지 메뉴
    ]
}
```

### 2. buildNavigationMenu 함수 개선
```javascript
item.children.forEach(child => {
    const childItem = document.createElement('li');
    const childLink = document.createElement('a');
    childLink.href = basePath + child.href;
    
    // ✅ 아이콘 지원 추가
    if (child.icon) {
        const icon = document.createElement('i');
        icon.className = child.icon;
        childLink.appendChild(icon);
        childLink.appendChild(document.createTextNode(' ' + child.label));
    } else {
        childLink.textContent = child.label;
    }
    
    // ... 나머지 코드
});
```

### 3. includes/header.html 업데이트
```html
<li class="nav-item has-dropdown">
    <a href="#" class="nav-link"><i class="fas fa-building"></i> 학회소개</a>
    <ul class="dropdown-menu">
        <li><a href="/pages/sitemap.html"><i class="fas fa-sitemap"></i> 웹 둘러보기</a></li>
        <li><a href="/pages/about/greeting-new.html">학회장 인사말</a></li>
        <!-- ... 나머지 메뉴 -->
    </ul>
</li>
```

### 4. index.html 메뉴 구조 통일
- ✅ 커뮤니티 > 자유게시판: `free-board.html`로 통일
- ✅ 마이페이지 메뉴에 `auth-only logged-in/logged-out` 클래스 추가

```html
<li class="nav-item has-dropdown">
    <a href="#" class="nav-link"><i class="fas fa-user-circle"></i> 마이페이지</a>
    <ul class="dropdown-menu">
        <!-- ✅ auth-only 클래스 추가 -->
        <li class="auth-only logged-out"><a href="pages/auth/signup.html">...</a></li>
        <li class="auth-only logged-in"><a href="pages/mypage/profile.html">...</a></li>
        <!-- ... -->
    </ul>
</li>
```

---

## 📊 수정된 파일 목록

| 파일 | 변경 내용 | 우선순위 |
|------|----------|---------|
| `js/main.js` | NAVIGATION_ITEMS에 "웹 둘러보기" 추가 + 아이콘 렌더링 로직 추가 | 🔴 높음 |
| `includes/header.html` | "웹 둘러보기" 메뉴 추가 | 🔴 높음 |
| `index.html` | 메뉴 구조를 main.js와 일치 (free-board.html, auth-only 클래스) | 🔴 높음 |
| `menu-test.html` | 메뉴 테스트 페이지 생성 | 🟡 중간 |

---

## 🧪 테스트 방법

1. **테스트 페이지 열기**: `menu-test.html`
2. **드롭다운 확인**:
   - "학회소개" 드롭다운 → 첫 번째에 "웹 둘러보기" 표시 확인
   - "커뮤니티" 드롭다운 → "자유게시판" 링크 확인
   - "마이페이지" 드롭다운 → 로그인 상태별 메뉴 표시 확인
3. **아이콘 렌더링**: 모든 메뉴 아이콘이 올바르게 표시되는지 확인
4. **호버 효과**: 드롭다운 항목에 마우스 올렸을 때 연한 녹색 배경 확인

---

## 🎯 근본 원인 분석

### 왜 이런 문제가 발생했나?

1. **중복 관리의 문제**
   - 메뉴가 3곳에서 관리됨: `main.js`, `includes/header.html`, `index.html`
   - 한 곳을 수정하면 다른 곳도 수정해야 하는데 누락됨

2. **동적/정적 메뉴 혼용**
   - main.js는 동적으로 메뉴를 생성
   - index.html은 정적 HTML로 메뉴 작성
   - 두 방식이 충돌하여 일관성 상실

3. **파일명 표준 부재**
   - `forum.html`과 `free-board.html` 중 어느 것을 써야 하는지 명확하지 않음
   - 개발 과정에서 파일명이 변경되었으나 모든 링크가 업데이트되지 않음

4. **로그인 상태 처리 미비**
   - CSS로 로그인 상태를 제어하는데 필요한 클래스가 누락됨
   - `auth-only`, `logged-in`, `logged-out` 클래스의 일관성 부재

---

## 💡 향후 개선 방안

### 1. **단일 진실 공급원(Single Source of Truth)**
```javascript
// main.js에만 메뉴 정의를 두고
// 모든 페이지가 이를 참조하도록 통일
```

### 2. **자동화된 메뉴 생성**
```javascript
// header를 동적으로 로드하는 방식으로 변경
// includes/header.html을 fetch로 불러와서 삽입
```

### 3. **파일명 표준화**
- 중복 파일 제거: `forum.html` 또는 `free-board.html` 중 하나만 유지
- 링크 일괄 업데이트 스크립트 작성

### 4. **타입 체크 도입**
```javascript
// NAVIGATION_ITEMS 구조를 TypeScript로 정의
interface MenuItem {
    label: string;
    icon?: string;
    href: string;
    matches?: string[];
    children?: ChildMenuItem[];
}
```

---

## ✨ 검증 완료

- ✅ "웹 둘러보기" 메뉴가 모든 페이지에서 표시됨
- ✅ 드롭다운 아이콘이 정상 렌더링됨
- ✅ 커뮤니티 > 자유게시판 링크 통일됨
- ✅ 마이페이지 로그인 상태 메뉴 작동함
- ✅ main.js, includes/header.html, index.html 일관성 확보

---

## 📝 결론

메뉴 드롭다운 문제는 **메뉴 정의가 여러 곳에 분산**되어 있고, **동적 생성 로직이 모든 케이스를 커버하지 못했기 때문**에 발생했습니다. 

이번 수정으로 다음이 달성되었습니다:
- ✅ 메뉴 구조 통일
- ✅ 아이콘 렌더링 지원
- ✅ 로그인 상태 메뉴 처리
- ✅ 파일 링크 표준화

향후에는 **단일 진실 공급원** 원칙을 적용하여 메뉴를 한 곳에서만 관리하고, 자동화된 메뉴 생성 시스템을 도입하는 것을 권장합니다.

---

**작성자**: AI Assistant  
**검토**: 완료  
**배포**: 즉시 적용 가능
