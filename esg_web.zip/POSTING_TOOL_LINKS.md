# 📍 포스팅툴 접근 링크 가이드

## 현재 프로젝트 URL 구조

**기본 URL**: `https://www.genspark.ai/api/code_sandbox_light/preview/68d5a3b6-99a3-44d6-8a91-440bc5253b4c/`

**쿼리 파라미터**: `?canvas_history_id=bd8255b8-e628-4063-9269-b2a901665fe9`

---

## 🎯 주요 페이지 직접 링크

### 1. 테스트 페이지 (가장 쉬운 접근)
```
https://www.genspark.ai/api/code_sandbox_light/preview/68d5a3b6-99a3-44d6-8a91-440bc5253b4c/posting-tool-access.html?canvas_history_id=bd8255b8-e628-4063-9269-b2a901665fe9
```

**특징**:
- ✅ 자동 로그인 처리
- ✅ 포스팅툴/히스토리 관리 직접 접근 버튼
- ✅ 데모 계정 정보 표시
- ✅ 가장 빠르고 편리함

---

### 2. 포스팅툴 메인 페이지
```
https://www.genspark.ai/api/code_sandbox_light/preview/68d5a3b6-99a3-44d6-8a91-440bc5253b4c/pages/admin/posting-tool.html?canvas_history_id=bd8255b8-e628-4063-9269-b2a901665fe9
```

**기능**:
- 3개 슬라이드 동시 편집
- 이미지 업로드/URL 입력
- AI 기반 텍스트 최적화
- 실시간 미리보기
- 버전 저장 및 게시

---

### 3. 히스토리 관리 페이지
```
https://www.genspark.ai/api/code_sandbox_light/preview/68d5a3b6-99a3-44d6-8a91-440bc5253b4c/pages/admin/history-manager.html?canvas_history_id=bd8255b8-e628-4063-9269-b2a901665fe9
```

**기능**:
- 모든 버전 목록 조회
- 버전 검색 (제목/작성자)
- 3개 슬라이드 미리보기
- 버전 적용 (메인페이지 즉시 반영)
- 수정하기 (포스팅툴로 이동)
- 삭제하기

---

### 4. 메인 페이지
```
https://www.genspark.ai/api/code_sandbox_light/preview/68d5a3b6-99a3-44d6-8a91-440bc5253b4c/index.html?canvas_history_id=bd8255b8-e628-4063-9269-b2a901665fe9
```

**설명**: 포스팅툴에서 수정한 히어로 슬라이더가 실시간으로 반영되는 페이지

---

### 5. 마이페이지 (관리자 메뉴)
```
https://www.genspark.ai/api/code_sandbox_light/preview/68d5a3b6-99a3-44d6-8a91-440bc5253b4c/pages/mypage/profile.html?canvas_history_id=bd8255b8-e628-4063-9269-b2a901665fe9
```

**경로**: 로그인 → 마이페이지 → 관리자 메뉴 → 포스팅툴 버튼

---

## 🚀 빠른 접근 방법 (추천)

### 방법 1: 테스트 페이지 사용 (⭐ 가장 추천)

**1단계**: 아래 링크 클릭
```
https://www.genspark.ai/api/code_sandbox_light/preview/68d5a3b6-99a3-44d6-8a91-440bc5253b4c/posting-tool-access.html?canvas_history_id=bd8255b8-e628-4063-9269-b2a901665fe9
```

**2단계**: "포스팅툴 열기" 버튼 클릭

**소요 시간**: 5초

---

### 방법 2: 직접 포스팅툴 접근

**링크 클릭**:
```
https://www.genspark.ai/api/code_sandbox_light/preview/68d5a3b6-99a3-44d6-8a91-440bc5253b4c/pages/admin/posting-tool.html?canvas_history_id=bd8255b8-e628-4063-9269-b2a901665fe9
```

**주의**: 로그인이 필요할 수 있습니다.

**데모 계정**:
- ID: `test@esg.or.kr`
- PW: `password123`

---

### 방법 3: 정식 경로 (안정적)

**1단계**: 메인페이지 접속
```
https://www.genspark.ai/api/code_sandbox_light/preview/68d5a3b6-99a3-44d6-8a91-440bc5253b4c/index.html?canvas_history_id=bd8255b8-e628-4063-9269-b2a901665fe9
```

**2단계**: 우측 상단 "로그인" 클릭

**3단계**: 데모 계정으로 로그인
- ID: `test@esg.or.kr`
- PW: `password123`

**4단계**: 로그인 후 우측 상단 "마이페이지" 클릭

**5단계**: 좌측 메뉴에서 "관리자 메뉴" 섹션 찾기

**6단계**: "포스팅툴" 버튼 클릭

---

## 📋 링크 요약 표

| 페이지 | URL 경로 | 용도 |
|--------|----------|------|
| 테스트 페이지 | `/posting-tool-access.html` | 가장 빠른 접근 |
| 포스팅툴 | `/pages/admin/posting-tool.html` | 슬라이드 편집 |
| 히스토리 관리 | `/pages/admin/history-manager.html` | 버전 관리 |
| 메인페이지 | `/index.html` | 결과 확인 |
| 마이페이지 | `/pages/mypage/profile.html` | 관리자 메뉴 |

---

## 🔧 브라우저 콘솔에서 접근

미리보기 탭에서 브라우저 콘솔(F12)을 열고 아래 명령어 실행:

### 포스팅툴로 이동
```javascript
window.location.href = 'pages/admin/posting-tool.html?canvas_history_id=bd8255b8-e628-4063-9269-b2a901665fe9';
```

### 테스트 페이지로 이동
```javascript
window.location.href = 'posting-tool-access.html?canvas_history_id=bd8255b8-e628-4063-9269-b2a901665fe9';
```

### 히스토리 관리로 이동
```javascript
window.location.href = 'pages/admin/history-manager.html?canvas_history_id=bd8255b8-e628-4063-9269-b2a901665fe9';
```

---

## ⚠️ 주의사항

1. **canvas_history_id 파라미터**
   - 현재 세션: `bd8255b8-e628-4063-9269-b2a901665fe9`
   - 새로운 세션에서는 ID가 변경될 수 있음
   - 변경 시 URL의 쿼리 파라미터를 새로운 ID로 교체

2. **로그인 상태**
   - 테스트 페이지는 자동 로그인 처리됨
   - 직접 접근 시 로그인이 필요할 수 있음
   - LocalStorage에 사용자 정보 저장됨

3. **권한 체크**
   - 현재는 프론트엔드 시뮬레이션
   - 실제 배포 시 서버 기반 권한 검증 필요

---

## 🎯 권장 워크플로우

```
1. 테스트 페이지 접속
   ↓
2. "포스팅툴 열기" 클릭
   ↓
3. 슬라이드 편집 (이미지/텍스트)
   ↓
4. "저장 및 게시" 클릭
   ↓
5. 메인페이지에서 결과 확인
   ↓
6. 필요 시 히스토리 관리에서 버전 관리
```

---

## 📞 문의

- 이메일: admin@esg.or.kr
- 전화: 010-4263-7715

---

**마지막 업데이트**: 2025년 12월 31일
**버전**: v1.0
**프로젝트**: 한국ESG학회 공식 웹사이트
